import React from 'react'

const CO2_resources = () => {
    return (
        <div>
            CO2_resources
        </div>
    )
}

export default CO2_resources

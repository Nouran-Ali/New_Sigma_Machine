import React from 'react'

const Laser_marking_resources = () => {
  return (
    <div>
      Laser_marking_resources
    </div>
  )
}

export default Laser_marking_resources

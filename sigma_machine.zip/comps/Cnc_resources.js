import React from 'react'

const Cnc_resources = () => {
  return (
    <div>
      Cnc_resources
    </div>
  )
}

export default Cnc_resources
